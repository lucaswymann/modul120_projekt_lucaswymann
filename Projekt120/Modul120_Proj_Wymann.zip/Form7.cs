﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void tracksBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tracksBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.projekt_120DataSet2);

        }

        private void Form7_Load(object sender, EventArgs e)
        {
            // TODO: Diese Codezeile lädt Daten in die Tabelle "projekt_120DataSet2.tracks". Sie können sie bei Bedarf verschieben oder entfernen.
            this.tracksTableAdapter.Fill(this.projekt_120DataSet2.tracks);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form Form1 = new Form1();
            Visible = false;
            Form1.Show();
        }
    }
}
