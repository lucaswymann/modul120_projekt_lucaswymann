﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
         PictureBox PictureBox1 = new PictureBox();
        Form Frm1 = new Form();
        

       // private string connectionString;
        public Form1()

        {
            
            InitializeComponent();
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Sizes (object sender, EventArgs e)
        {
            Frm1.Size = new System.Drawing.Size(1920, 1200);
            Frm1.Width += 1920;
            Frm1.Height += 1200;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form Form4 = new Form4();
            Visible = false;
            Form4.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            Visible = false;
            form2.Show();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Form Form3 = new Form3();
            Visible = false;
            Form3.Show();           
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Form Form2 = new Form2();
            Visible = false;
            Form2.Show();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            string connetionString = null;
            System.Data.SqlClient.SqlConnection cnn;
            connetionString = "Data Source=BMWP2;Initial Catalog=projekt_120;User ID=vmadmin;Password=lw230199";
            cnn = new System.Data.SqlClient.SqlConnection(connetionString);
            try
            {
                cnn.Open();
                MessageBox.Show("Connection Open ! ");
                cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: Diese Codezeile lädt Daten in die Tabelle "projekt_120DataSet.playlists". Sie können sie bei Bedarf verschieben oder entfernen.
            this.playlistsTableAdapter.Fill(this.projekt_120DataSet.playlists);
            // TODO: Diese Codezeile lädt Daten in die Tabelle "projekt_120DataSet.news". Sie können sie bei Bedarf verschieben oder entfernen.
            this.newsTableAdapter.Fill(this.projekt_120DataSet.news);
            // TODO: Diese Codezeile lädt Daten in die Tabelle "projekt_120DataSet.tracks". Sie können sie bei Bedarf verschieben oder entfernen.
            this.tracksTableAdapter.Fill(this.projekt_120DataSet.tracks);
            AutoSize = true;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Form Form5 = new Form5();
            Visible = false;
            Form5.Show();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form Form5 = new Form5();
            Visible = false;
            Form5.Show();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Form Form2 = new Form2();
            Visible = false;
            Form2.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            Form Form4 = new Form4();
            Visible = false;
            Form4.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Form Form6 = new Form6();
            Visible = false;
            Form6.Show();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            
        }



        /* private void cmd_Suchen_Click (object sender, EventArgs e)
         {
             string Unternehmen = txt_tracks.Text;
             string Ansprechpartner = txt_playlists.Text;

             string id = "";
             string titel = "select titel from tracks";
             string interpret = "select interpret from tracks";
             string album = "select album from tracks";
             System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(connectionString);
             con.Open();

             //  Verfassung des SQL Statements, damit klar wird, 
             //  worauf in der Datenbak zugegriffen werden soll.
             System.Data.SqlClient.SqlCommand cmd = con.CreateCommand();
             cmd.CommandText = "SELECT * FROM Customers WHERE ContactName = @Name";
             cmd.Parameters.AddWithValue("titel", tracks);


             //  Senden der SQL Abfrage
             System.Data.SqlClient.SqlDataReader dr = cmd.ExecuteReader();

          //  SQL Abfrage auswerten und ausgeben
             while (dr.Read())
             {

                 lbl_id.int = dr.GetString(3);
                 lbl_title.Text = dr.GetString(4);
                 lbl_interpret.Text = dr.GetString(5);
                 lbl_album.Text = dr.GetString(6);

             }



 }
    */

    }
}
