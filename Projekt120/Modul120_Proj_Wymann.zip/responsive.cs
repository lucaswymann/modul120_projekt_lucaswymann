﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
   /* class Responsive
    {
        float WITH_ATWIDTH_AT_DESIGN_TIME = (float)Convert.ToDouble
                              (ConfigurationManager.AppSettings["DESIGN_TIME_SCREEN_WIDTH"]);
        float HEIGHT_AT_DESIGN_TIME = (float)Convert.ToDouble
                              (ConfigurationManager.AppSettings["DESIGN_TIME_SCREEN_HEIGHT"]);

        Rectangle Resolution;
        float WidthMultiplicationFactor;
        float HeightMultiplicationFactor;
        public Responsive(Rectangle ResolutionParam)
        {
            Resolution = ResolutionParam;
        }

        public int WIDTH_AT_DESIGN_TIME { get; private set; }

        public void SetMultiplicationFactor()
        {
              WidthMultiplicationFactor = Resolution.Width / WIDTH_AT_DESIGN_TIME;
              HeightMultiplicationFactor = Resolution.Height / HEIGHT_AT_DESIGN_TIME;
        }
    }

    class ConfigurationManager
    {
    }*/
}
