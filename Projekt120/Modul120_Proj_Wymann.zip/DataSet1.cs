﻿namespace $safeprojectname$
{


    partial class DataSet1
    {
        partial class DataTable1DataTable
        {

        }
    }
}
