﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form Form4 = new Form4();
            Visible = false;
            Form4.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form Form1 = new Form1();
            Visible = false;
            Form1.Show();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            string connetionString = null;
            System.Data.SqlClient.SqlConnection cnn;
            connetionString = "Data Source=BMWP2;Initial Catalog=projekt_120;User ID=vmadmin;Password=lw230199";
            cnn = new System.Data.SqlClient.SqlConnection(connetionString);
            try
            {
                cnn.Open();
                MessageBox.Show("Connection Open ! ");
                cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void playlistsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.playlistsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.projekt_120DataSet);

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: Diese Codezeile lädt Daten in die Tabelle "projekt_120DataSet.tracks". Sie können sie bei Bedarf verschieben oder entfernen.
            this.tracksTableAdapter.Fill(this.projekt_120DataSet.tracks);
            // TODO: Diese Codezeile lädt Daten in die Tabelle "projekt_120DataSet.playlists". Sie können sie bei Bedarf verschieben oder entfernen.
            this.playlistsTableAdapter.Fill(this.projekt_120DataSet.playlists);

        }

        private void label4_Click(object sender, EventArgs e)
        {
            label4.Size = new System.Drawing.Size(191, 65);
        }

        private void button17_Click(object sender, EventArgs e)
        {
            Form Form7 = new Form7();
            Visible = false;
            Form7.Show();
        }

        private void button17_Click_1(object sender, EventArgs e)
        {
            Form Form7 = new Form7();
            Visible = false;
            Form7.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form Form5 = new Form5();
            Visible = false;
            Form5.Show();
        }

        /* private void playlistsDataGridView_CellEnter(object sender, DataGridViewCellEventArgs e)
         {
             string mySQL = "insert into playlists values (playlist, anzahlTracks, )"
         }*/
    }
}
