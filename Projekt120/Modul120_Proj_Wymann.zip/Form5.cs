﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form Form1 = new Form1();
            Visible = false;
            Form1.Show();
        }

        private void newsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.newsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.projekt_120DataSet);

        }

        private void Form5_Load(object sender, EventArgs e)
        {
            // TODO: Diese Codezeile lädt Daten in die Tabelle "projekt_120DataSet2.news". Sie können sie bei Bedarf verschieben oder entfernen.
            this.newsTableAdapter1.Fill(this.projekt_120DataSet2.news);
            // TODO: Diese Codezeile lädt Daten in die Tabelle "projekt_120DataSet.news". Sie können sie bei Bedarf verschieben oder entfernen.
            this.newsTableAdapter.Fill(this.projekt_120DataSet.news);

        }

        
    }
}
